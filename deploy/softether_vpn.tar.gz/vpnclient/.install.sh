#!/bin/sh

echo "--------------------------------------------------------------------"
echo
echo "SoftEther VPN Client (Ver 4.43, Build 9799, ARM 64bit) for Linux Build Utility"
echo "Copyright (c) SoftEther Project at University of Tsukuba, Japan. All Rights Reserved."
echo
echo "--------------------------------------------------------------------"
echo
echo

cat ReadMeFirst_License.txt

echo
echo "--------------------------------------------------------------------"
echo
echo

make main

exit 0

